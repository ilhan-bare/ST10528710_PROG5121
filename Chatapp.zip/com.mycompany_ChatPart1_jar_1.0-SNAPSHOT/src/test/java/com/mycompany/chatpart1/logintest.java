package com.mycompany.chatpart1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*; 

public class logintest {

    // Create Login object
    Login login = new Login();

    // ================= USERNAME TESTS =================

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUsername("kyl_1"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUsername("kyle"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        assertFalse(login.checkUsername("kyle_123"));
    }

    // ================= PASSWORD TESTS =================

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPassword_NoCapital() {
        assertFalse(login.checkPasswordComplexity("password123!"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password!!!"));
    }

    @Test
    public void testInvalidPassword_NoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Password123"));
    }

    // ================= PHONE NUMBER TESTS =================

    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_NoCountryCode() {
        assertFalse(login.checkCellPhoneNumber("083898976"));
    }

    @Test
    public void testInvalidPhoneNumber_WrongLength() {
        assertFalse(login.checkCellPhoneNumber("+2783"));
    }

    // ================= LOGIN FLOW TESTS =================

    @Test
    public void testLoginSuccess() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFail_WrongUsername() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("wrongUser", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFail_WrongPassword() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrongPass"));
    }

    // ================= REGISTER TEST =================

    @Test
    public void testRegisterUserSuccess() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("User registered successfully.", result);
    }
}